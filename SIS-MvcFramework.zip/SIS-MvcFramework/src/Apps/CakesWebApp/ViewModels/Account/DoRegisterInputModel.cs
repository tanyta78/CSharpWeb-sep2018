﻿namespace CakesWebApp.ViewModels.Account
{
    public class DoRegisterInputModel
    {
        public string Username { get; set; }

        public string Password { get; set; }

        public string ConfirmPassword { get; set; }
    }
}
