﻿namespace CakesWebApp
{
    using SIS.MvcFramework;

    public class Program
    {
        public static void Main(string[] args)
        {
            WebHost.Start(new Startup());
        }
    }
}
