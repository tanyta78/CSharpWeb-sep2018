﻿namespace ChushkaWebApp.ViewModels.Products
{
    public class UpdateDeleteProductInputModel : CreateProductInputModel
    {
        public int Id { get; set; }
    }
}
