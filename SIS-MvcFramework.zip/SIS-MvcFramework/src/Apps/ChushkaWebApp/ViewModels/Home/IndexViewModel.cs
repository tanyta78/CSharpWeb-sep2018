﻿using System.Collections.Generic;

namespace ChushkaWebApp.ViewModels.Home
{
    public class IndexViewModel
    {
        public IEnumerable<ProductViewModel> Products { get; set; }
    }
}
