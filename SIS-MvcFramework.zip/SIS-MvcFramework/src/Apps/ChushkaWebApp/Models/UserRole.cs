﻿namespace ChushkaWebApp.Models
{
    public enum UserRole
    {
        User = 1,
        Admin = 2,
    }
}