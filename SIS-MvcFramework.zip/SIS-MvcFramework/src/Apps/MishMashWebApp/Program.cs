﻿using SIS.MvcFramework;

namespace MishMashWebApp
{
    class Program
    {
        static void Main(string[] args)
        {
            WebHost.Start(new Startup());
        }
    }
}
