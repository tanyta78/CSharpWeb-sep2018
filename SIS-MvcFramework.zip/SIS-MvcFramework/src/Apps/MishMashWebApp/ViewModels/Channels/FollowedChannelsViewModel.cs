﻿using System.Collections.Generic;

namespace MishMashWebApp.ViewModels.Channels
{
    public class FollowedChannelsViewModel
    {
        public IEnumerable<BaseChannelViewModel> FollowedChannels { get; set; }
    }
}

