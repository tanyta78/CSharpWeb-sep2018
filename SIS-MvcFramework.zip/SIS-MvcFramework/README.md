# SoftUni Information Services - the IIS wannabe
**SoftUni Information Services** is a package of web services, including an **HTTP Server** and an **MVC Framework**, written both in C#. These web services are for educational purposes. They are mimicking the IIS and ASP.NET, and are used for the
**C# Web Development Basics Course** @ [**SoftUni**](https://softuni.bg)
