﻿namespace SIS.Framework.ActionResults
{
    public interface IActionResult
    {
        string Invoke();
    }
}
