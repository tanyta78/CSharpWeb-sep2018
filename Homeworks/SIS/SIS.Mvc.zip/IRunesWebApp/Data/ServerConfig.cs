﻿namespace IRunesWebApp.Data
{
   public class ServerConfig
    {
        public static string ConnectionString => "Server=DESKTOP-LAHCAG9\\SQLEXPRESS;Database=IRunesWebApp;Integrated Security=True;";
    }
}
