﻿namespace PandaWebApp.ViewModels.Packages
{
    public class RecipientViewModel
    {
        public int Id { get; set; }
        public string Username { get; set; }
    }
}
