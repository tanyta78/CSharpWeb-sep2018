﻿namespace SIS.MvcFramework.Services
{
    public interface IHashService
    {
        string Hash(string stringToHash);
    }
}
